package com.company;

public  class Grandmother {
    private Info info ;
    private int age ;
    private String name ;
    private List list ;

    public Grandmother(Info info, int age, String name, List list) {
        this.info = info;
        this.age = age;
        this.name = name;
        this.list = list;
    }

    public Info getInfo() {
        return info;
    }

    public int getAge() {
        return age;
    }

    public String getName() {
        return name;
    }

    public List getList() {
        return list;
    }
}
