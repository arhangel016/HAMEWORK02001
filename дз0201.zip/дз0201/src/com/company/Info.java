package com.company;

public class Info {
    private String titleHouse ;
    private String job ;

    public Info(String titleHouse, String job) {
        this.titleHouse = titleHouse;
        this.job = job;
    }

    public String getTitleHouse() {
        return titleHouse;
    }

    public String getJob() {
        return job;
    }
}
