package com.company;

public enum List {
        Samsung , Xiaomi , Iphone , Huawei
}
