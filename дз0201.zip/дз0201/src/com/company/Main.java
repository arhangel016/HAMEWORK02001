package com.company;

public class Main {

    public static void main(String[] args) {
        Mother mother = new Mother(new Info("Home", "Doctor"), 30, "Roza", List.Iphone, 100000, "not");
        Daughter daughter1 = new Daughter(new Info("Home", "Not"), 10, "Kate", List.Xiaomi, 1000, "dog", "Razakov", 10);
        Daughter daughter2 = new Daughter(new Info("Home", "Not"), 7, "Kate", List.Samsung, 10, "cat", "Razakov", 0);
            mother.getTop(List.Huawei);
            mother.getTop();
            mother.getTop("Hospital",List.Huawei , 70000);
        System.out.println("----------------");
            daughter1.getTop();
        System.out.println("----------------");
        daughter2.getTop();
    }
}
